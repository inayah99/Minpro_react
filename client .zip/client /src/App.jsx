import React from 'react';
import Header from './components/header';
import Dashboard from "./pages/dashboard";
import Login from "./pages/auth/login";
import CatalogById from "./pages/catalog";
import Register from "./pages/auth/register";
import PageNotFound from "./pages/notFound";
import {
  Routes,
  Route,
  Navigate,
  BrowserRouter,
  Outlet,
} from 'react-router-dom';

const RequiredAuth = () => {
  let isAuth = localStorage.getItem('access_token')

  if (!isAuth) {
    return <Navigate to="/"/>
  }

  return (
  <>
  <Header />
  <Outlet/>
  </>
  )
}


const App = () => {

      
  return(
    <>
    <BrowserRouter>
      <Routes>
        {/* public routes */}
        <Route>
          <Route path="/" element={<CatalogById/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/register" element={<Register/>}/> 
        
        {/* protected routes pages */}
        <Route element={<RequiredAuth/>}>
          {/* list of requiredAuth Outlet */}
          <Route index path="/dashboard" element={<Dashboard/>}/>
          </Route>
        </Route>

        {/* not found page */}
        <Route path="*" element={<PageNotFound/>} />
      </Routes>
    </BrowserRouter>
    </>
  )
}

export default App;


