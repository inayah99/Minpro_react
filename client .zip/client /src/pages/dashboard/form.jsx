import React, { useState, useEffect } from "react";
import { FormGroup, Label, Row, Input, Button, Col } from "reactstrap";
import { Form } from "reactstrap";
import request from "../../helpers/request";

const FormProduct = ({ type, setFormVisible, formEdited, refetch }) => {

    const [name, setName] = useState('');
    const [quantity, setQuantity] = useState(0);
    const [price, setPrice] = useState(0);

    const handleSubmit = async (e) => {
        
        e.preventDefault();

        const form = { name, quantity, price };

        if (type === 'create') {
            await request
                .post('/product', form)
                .then(() => refetch())
                .catch((err) => alert(err))
        } else {
            await request
                .put(`/product/${formEdited.id}`, form 
                )
                .then(() => refetch())
                .catch((err) => alert(err))
        }
        setFormVisible(false);
    }


    useEffect(() => {
        if(type === "edit") {
            setName(formEdited.name)
            setQuantity(formEdited.quantity)
            setPrice(formEdited.price)
        }
    }, [type, formEdited])

    return(
    <>
        <Row>
            <Form onSubmit={handleSubmit}>
                <>
                <FormGroup>
                    <Label>Name</Label>
                    <Input
                        type="text"
                        value={name}
                        placeholder="Product Name"
                        onChange={(e) => setName(e.target.value)}
                        required
                    />
                </FormGroup>

                <FormGroup>
                    <Label>Quantity</Label>
                    <Input
                        type="number"
                        value={quantity}
                        placeholder="Quantity"
                        onChange={(e) => setQuantity(e.target.value)}
                        required
                    />
                </FormGroup>

                <FormGroup>
                    <Label>Price</Label>
                    <Input
                        type="number"
                        value={price}
                        placeholder="Price"
                        onChange={(e) => setPrice(e.target.value)}
                        required
                    />
                </FormGroup>
                </>
                <Row>
                    <Col>
                        <Button color="primary" type="submit">Submit</Button>
                    </Col>
                    <Col>
                        <Button onClick={() => setFormVisible(false)}>Cancel</Button>
                    </Col>
                    

                </Row>
              
            </Form>
        </Row>
    </>
    )

}

export default FormProduct;