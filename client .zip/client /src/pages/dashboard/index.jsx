import { useEffect, useState } from "react";
import {
    Button,
    Row,
    Col,
    ModalBody,
    ModalHeader,
    Table,
    Modal
} from 'reactstrap';
import request from "../../helpers/request";
import ProductInformation from "./form";

const Dashboard = () => {
    const [productList, setProductList] = useState([]);
    const [formType, setFormType] = useState(null);
    const [formVisible, setFromVisible] = useState(false);
    const [formEdited, setFormEdited] = useState({});

    const handleAddProduct = () => {
        setFormType('create');
        setFromVisible(true)
    }

    const handleEdit = (form) => {
        setFormEdited(form);
        setFormType('edit');
        setFromVisible(true);
    }

    const handleDelete = (id) => {
        request.delete(`/product/${id}`)
        .then(() => fetchData())
        .catch(err => console.log(err))
    }

    const fetchData = async () => {
       await request.get(`/product`)
        .then (({data} )  => {
            setProductList(data);
           
        })
        .catch(err => alert(err))

    }

    useEffect( () => {
            fetchData();
    }, [] )

    return (
        <div className="dashboard-container" style={{margin:"0px 250px"}}>
            <h1>Product List</h1>
            <br/>
           <Row>
               <Col>
               <Button color="primary" onClick= {() => handleAddProduct()}>Add Product</Button> 
               </Col>
            </Row> 
            <br/>
            <Table striped width={200}>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                    </tr>
                </thead>


                <tbody>
                    {productList.map((row, idx) => (
                        <tr key={idx}>
                            <th scope="row">
                                {idx + 1}
                            </th>
                            {/* <td>{row.id}</td> */}
                            <td>{row.name}</td>
                            <td>{row.quantity}</td>
                            <td>{row.price}</td>
                            <td>
                                <Button 
                                
                                  onClick={() => handleEdit(row)}
                                >
                                  Edit
                                </Button>
                                &nbsp; &nbsp;
                                <Button 
                                  color="danger" 
                                  onClick={() => handleDelete(row.id)}
                                >
                                  Delete
                                  </Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>

            {/* Modal Form */}
            <Modal isOpen={formVisible} toggle={() => setFromVisible(!formVisible)}>
                    <ModalHeader>{`Form ${formType} data`}</ModalHeader>
                    <ModalBody>
                        <ProductInformation
                        type = {formType}
                        refetch = {fetchData}
                        setFromVisible={setFromVisible}
                        formEdited={formEdited}
                        />
                    </ModalBody>
            </Modal>
        </div>
    )

}

export default Dashboard