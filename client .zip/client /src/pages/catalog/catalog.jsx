import React, { useState, useEffect } from 'react';
import './style.css'

const FormInput = ({type, formEdited}) => {

  const [name, setName] = useState("")
  const [setDescription] = useState("")
  const [quantity, setQuantity] = useState(0)
  const [setPrice] = useState(0)

  useEffect(() => {
    if (type === "detail") {
      setName(formEdited.name)
      setDescription(formEdited.description)
      setQuantity(formEdited.quantity)
      setPrice(formEdited.price)
    }
  }, [formEdited, setDescription, setPrice, type])

  console.log("formedited: ", formEdited)

  return (
      <div className='detail_page'>
          <p> Flash Sale {quantity} remaining {name}. Get <b>best price</b> on purchases today. </p>
      </div>
  )

}

export default FormInput